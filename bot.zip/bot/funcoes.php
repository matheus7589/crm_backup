<?php

//class Funcoes
//{
//    public $tgLog;
    function get_conn()
    {
        $loop = Factory::create();
        $tgLog = new TgLog(BOT_TOKEN, new HttpClientRequestHandler($loop));
        return true;
    }

    function mostra_menu_cliente()
    {
//        $tgLog = get_conn();
//        $sendMessage = new SendMessage();
//        $sendMessage->chat_id = A_USER_CHAT_ID;
//        $cliente = $conn->query("SELECT * FROM `tblclients` WHERE `userid` = '" . $row['userid'] . "'");
//        $cliented = mysqli_fetch_assoc($cliente);
        $text = $_SESSION['company'] . "\n\n";
        $text .= "Verificar tickets abertos: \t/Tickets\n";
        $text .= "Sair: \t/Sair";
        return $text;
//        $text .= "";
//        $sendMessage->text = "";
//        $tgLog->performApiRequest($sendMessage);
//
    }

    function main_menu()
    {
        $text = $_SESSION['first_name'] . ", Bem vindo ao Sistema Quantum!\n";
        $text .= "Verificamos que você não está logado.\n\n";
        $text .= "/SouCliente\n";
        $text .= "/SouColaborador\n";
        return $text;
    }
//}