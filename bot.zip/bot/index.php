<?php
//    ini_set('display_errors', 0 );
//    error_reporting(0);
    session_start();
    include __DIR__.'/vendor/autoload.php';
    require "conexao.php";
    require "funcoes.php";

    use \React\EventLoop\Factory;
    use \unreal4u\TelegramAPI\HttpClientRequestHandler;
    use \unreal4u\TelegramAPI\TgLog;
    use \unreal4u\TelegramAPI\Telegram\Methods\SendMessage;
    use Longman\TelegramBot\Commands\UserCommand;
    use Longman\TelegramBot\Entities\Keyboard;
    use Longman\TelegramBot\Request;
//    $updates = file_get_contents("php://input");
//    $updates = json_decode($updates, true);
    $updates = json_decode($_POST['data'], true);
    $text_s = $updates["message"]["text"];
    $chatID = $updates["message"]["chat"]["id"];
    $userID = $updates["message"]["from"]["id"];
    $_SESSION['first_name'] = $updates["message"]["chat"]["first_name"];

    define('BOT_TOKEN', '556575090:AAE4HwnZzgvnEx_FCf_yg5mStn45_CYRaKU');
    define('A_USER_CHAT_ID', $chatID);
//        define('A_USER_CHAT_ID', '359131846 ');
//    $tgLog = get_conn();
    $loop = Factory::create();
    $tgLog = new TgLog(BOT_TOKEN, new HttpClientRequestHandler($loop));

    $sendMessage = new SendMessage();
    $sendMessage->chat_id = A_USER_CHAT_ID;

    if ($conn == false)
        $text = "Serviço indisponível no momento.\nTente mais tarde.";
    else
    {
        /** Pegando dados do usuario */
        $result = $conn->query("SELECT * FROM atbltelegbot_sessions WHERE telegram_userid = '" . $userID . " AND flag_ativo = 1 LIMIT 0,1'");
        $row = mysqli_fetch_assoc($result);

        $ultimocomando = $row['ultimo_comando'];
        $text = "nada".$userID;

        if ($row)
        {
            if($row['userid'] != NULL || $row['staffid'] != NULL)
            {
                if($row['userid'] != NULL)
                {
                    $cliente = $conn->query("SELECT * FROM `tblclients` WHERE `userid` = '" . $row['userid'] . "'");
                    $cliented = mysqli_fetch_assoc($cliente);
                    switch (strtolower($text_s)) {
                        case "/tickets":
                            $tickets = $conn->query("SELECT ticketid,subject,tblticketstatus.name as statusn FROM `tbltickets` INNER JOIN tblticketstatus ON ticketstatusid = status WHERE status IN (1,2) AND userid = ".$row['userid']);
                            $text = "Tickets abertos\n";
                            while($ticket = mysqli_fetch_assoc($tickets))
                                $text .= "\n".$ticket['ticketid']." - ".$ticket['subject']." [".$ticket['statusn']."]\n";
                            if($text == "")
                                $text = "Nenhum Ticket 'Aberto ou Pedente' encontrado.\n\n";
//                            $text .= "SELECT * FROM `tbltickets` WHERE status IN (1,2) AND userid = ".$row['userid'];
                            break;
                        case "/sair":
                            $text = "Até logo!!\n\n/start";
                            $conn->query("UPDATE `atbltelegbot_sessions` SET `ultimo_comando` = NULL, `userid` = NULL, `staffid` = NULL WHERE `atbltelegbot_sessions`.`id_session` = " . $row['id_session']);
                            $text = main_menu();
                            break;
                        default:
                            $text = mostra_menu_cliente();
                    }
                }
                if($row['staffid'] != NULL)
                {
                    $staff = $conn->query("SELECT * FROM `tblstaff` WHERE `email` = '" . strtolower($text_s) . "'");
                    $staffd = mysqli_fetch_assoc($staff);
                    switch (strtolower($text_s))
                    {
                        case "a":
                            $text = "A";
                            break;
                        case "/sair":
                            $text = "Até logo!!\n\n/start";
                            $conn->query("UPDATE `atbltelegbot_sessions` SET `ultimo_comando` = NULL, `userid` = NULL, `staffid` = NULL WHERE `atbltelegbot_sessions`.`id_session` = " . $row['id_session']);
                            $text = main_menu();
                            break;
                        default:
                            $text = $staffd['fristname']." ".$staffd['lastname']."\nMeus Tickets: \t/Tickets\nSair: /Sair";
                    }
                }
            }
            else
            {
                switch (strtolower($text_s))
                {
                    case "/start":
                        $text = $_SESSION['first_name'] . ", Bem vindo ao Sistema Quantum!\n";
                        $text .= "Verificamos que você não está logado.\n\n";
                        $text .= "/SouCliente\n";
                        $text .= "/SouColaborador\n";
                        break;
                    case "/soucliente":
                        $text = "Digite o CPF/CNPJ";
                        $conn->query("UPDATE `atbltelegbot_sessions` SET `ultimo_comando` = 'obtem_cnpj_cliente' WHERE `atbltelegbot_sessions`.`id_session` = " . $row['id_session']);
                        break;
                    case "/soucolaborador":
                        $text = "Digite seu email de acesso do CRM";
                        $conn->query("UPDATE `atbltelegbot_sessions` SET `ultimo_comando` = 'obtem_email_staff' WHERE `atbltelegbot_sessions`.`id_session` = " . $row['id_session']);
                    break;
                    default:
                        if ($ultimocomando == "obtem_cnpj_cliente")
                        {
                            $text = "CNPJ: " . strtolower($text_s);
                            $cliente = $conn->query("SELECT * FROM `tblclients` WHERE `cnpj_or_cpf` = '" . strtolower($text_s) . "'");
                            $cliented = mysqli_fetch_assoc($cliente);
                            if ($cliented)
                            {
//                                $text = "Seja bem vindo: " . $cliented['company']."\n\nMenu: \t/Menu";
                                $conn->query("UPDATE `atbltelegbot_sessions` SET `ultimo_comando` = NULL, `userid` = '" . $cliented['userid'] . "' WHERE `atbltelegbot_sessions`.`id_session` = " . $row['id_session']);
                                $_SESSION['company'] = $cliented['company'];
                                $_SESSION['staff'] = $cliented;
                                $text = mostra_menu_cliente();
                            }
                            else
                                $text = "Cliente não encontrado.\n\nDigite o CPF/CNPJ";
                        }
                        else if($ultimocomando = "obtem_email_staff")
                        {
                            $text = "Email: " . strtolower($text_s);
                            $staff = $conn->query("SELECT * FROM `tblstaff` WHERE `email` = '" . strtolower($text_s) . "'");
                            $staffd = mysqli_fetch_assoc($staff);
                            if($staffd)
                            {
                                $conn->query("UPDATE `atbltelegbot_sessions` SET `ultimo_comando` = NULL, userid = NULL, `staffid` = '" . $staffd['staffid'] . "' WHERE `atbltelegbot_sessions`.`id_session` = " . $row['id_session']);
                                $_SESSION['fristname'] = $staffd['fristname'];
                                $text = $_SESSION['fristname'];
                            }
                            else
                                $text = "Colaborador não encontrado.\n\nDigite o Email";
                        }
                        else
                            $text = "Comando não encontrado: " . $text_s;
                }
            }
        }
        else
        {
            $conn->query("INSERT INTO `atbltelegbot_sessions`(`telegram_userid`, `data_created`, `flag_ativo`, `hash`, `userid`, `staffid`, `ultimo_comando`) VALUES ('".$userID."','".date("Y-m-d H:i:s")."','1','',NULL,NULL,NULL)");
            $text = "Seção Iniciada.\n/start";
        }
    }

//    $sendMessage->reply_markup = new Keyboard(['Need some help', 'Who am I?']);
    $sendMessage->text = $text;

    $tgLog->performApiRequest($sendMessage);
    $loop->run();
    $conn->close();
    session_destroy();