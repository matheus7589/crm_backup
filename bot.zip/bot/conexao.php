<?php

    $servername = "127.0.0.1:3390";
    $port = "3390";
    $dbname = "crm";
    $username = "root";
    $password = "root";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if (boolval($conn->connect_error))
        $conn = false;